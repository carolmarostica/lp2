package com.fatorial.trabalho.fatorial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button botao = (Button) findViewById(R.id.botao);
        final EditText campo = (EditText) findViewById(R.id.campo);
        final TextView res = (TextView) findViewById(R.id.res);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int x = Integer.parseInt(campo.getText().toString());
                int f = x;
                while(f>1){
                    x = x*(f-1);
                    f--;
                }

                res.setText("" + x);

            }
        });
    }
}
