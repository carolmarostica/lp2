package com.example.alunos.medtime;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.alunos.RestFulClient.RestFulClient;

public class AddActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
    }
    public void salvar(){
        AsyncTask taskWsSalvar = new ConnectionRemedio();
        taskWsSalvar.execute();
    }


    class ConnectionRemedio extends AsyncTask<Object, Integer, Void>{
        private RestFulClient cliente = new RestFulClient();

        @Override
        protected Void doInBackground(Object... params) {

            cliente.salvar("http://localhost:8080/restmongo/rest/remedio", "{id:valor, fotoRemedio: valor, nomeRemedio:valor,dose:valor,hrHr:valor,qntsDias:valor,comer:valor}");
            }
        }
    }
}
