package br.com.herbertrausch.spring.mongo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;

import br.com.herbertrausch.util.SpringUtil;

public class RemedioService {
	private RemedioRepository db;
	
public RemedioService(){
		
		ApplicationContext context=SpringUtil.getContext();
		db = context.getBean(RemedioRepository.class);
		
	}
	
	// Lista todos os remedios cadastrados do banco de dados
		public List<Remedio> getRemedio() {
			try {
				
				List<Remedio> remedio = (List<Remedio>) db.findAll();
						
				return remedio;
				
			} catch (Exception e) {
				e.printStackTrace();
				return new ArrayList<Remedio>();

			}
		}
		
		public List<Remedio> getByNome(String a){
			return db.findByNomeRemedio(a);
		}
		
		public List<Remedio> getByHrHr(int b){
			return db.findByHrHr(b);
		}

		public Remedio getRemedio(String id) {
			try {
				
				
				return db.findOne(id);
				
			}catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		// Deleta o cadastro pelo nomeRemedio
		public boolean delete(String nomeRemedio) {
			try {
				db.deleteBynomeRemedio(nomeRemedio);
				return true;
			} 
			catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
		
		// Salva ou atualiza o cadastro
		public boolean save(Remedio remedio) {
			try {
				
					db.save(remedio);
				
				return true;
			}  catch (Exception e) {
				e.printStackTrace();
				return false;
			}
		}
	

}
