package com.example.alunos.model;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;

import java.io.Serializable;
import java.util.ArrayList;

public class Remedio implements Serializable {

    private static final long serialVersionUID = 1L;



    private String nome;
    private String hora;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    /**
     * Recebe um json que representa um objeto e o transforma em Object
     * @param objectJson
     * @return
     */
    public static Remedio fromJson(String objectJson) {
        Gson gson = new Gson();
        Remedio e = gson.fromJson(objectJson, Remedio.class);
        return e;
    }

    /**
     * Recebe um json que representa uma lista de objetos e retorna em ArrayList<>
     * @param objectJson
     * @return
     */
    public static ArrayList<Remedio> fromArrayJson(String objectJson) {
        Gson gson = new Gson();
        ArrayList<Remedio> e = new ArrayList<Remedio>();

        JsonParser parser = new JsonParser();
        JsonArray array = parser.parse(objectJson).getAsJsonArray();

        int tamanho = array.size();
        for (int i = 0; i < tamanho; i++) {

            Remedio endereco = gson.fromJson(array.get(i), Remedio.class);
            e.add(endereco);
        }

        return e;
    }

}
