package com.example.alunos.medtime;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.alunos.helper.RestFulClient;
import com.example.alunos.model.Remedio;

import java.util.ArrayList;


public class AddActivity extends AppCompatActivity {
    Button btnSalvar;
    EditText editNome, editHora;
    Remedio objRemedio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        btnSalvar = (Button) findViewById(R.id.btnSalvar);
    }


    //quando o cara clicar no botao -> salvar o remedio
    //asyntask
    //RestFulClient - remedio


    public void salvarRemedio(View v){

        btnSalvar.setEnabled(false);

        objRemedio = new Remedio();

        editNome = (EditText) findViewById(R.id.editText);
        editHora = (EditText) findViewById(R.id.editText2);


        objRemedio.setNome(editNome.getText().toString());
        objRemedio.setHora(editHora.getText().toString());

        AsyncTask taskWs = new ConnectionRemedio();
        taskWs.execute();

    }

}
