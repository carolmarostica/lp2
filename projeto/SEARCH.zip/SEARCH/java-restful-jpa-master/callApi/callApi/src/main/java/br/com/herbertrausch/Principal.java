package br.com.herbertrausch;

import java.util.ArrayList;

import br.com.herbertrausch.domain.Endereco;
import br.com.herbertrausch.rest.RestFulClient;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RestFulClient ws = new RestFulClient();
		
		
		//LISTAR TODOS
		ws.recuperar("http://localhost:8080/restmongo/rest/remedio");
		
		//LISTAR POR NOME
		String remedio = "dipirona"; //findviewbyid ... getText()
		ws.recuperar("http://localhost:8080/restmongo/rest/nomedoRemedio/"+remedio);
		
		
		ws.closeConnection();
		

	}

}
