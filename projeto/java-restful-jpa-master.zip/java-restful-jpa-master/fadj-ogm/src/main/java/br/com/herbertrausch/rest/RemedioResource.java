package br.com.herbertrausch.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.herbertrausch.spring.mongo.Remedio;
import br.com.herbertrausch.spring.mongo.RemedioService;

@Path("/remedio")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class RemedioResource {

	public RemedioService remedioService = new RemedioService();
	
	@GET
	public List<Remedio> get() {
		List<Remedio> remedios = remedioService.getRemedio();
		return remedios;
	}

	@GET
	@Path("{id}")
	public Remedio get(@PathParam("id") long id) {
		Remedio r = remedioService.getRemedio(id);
		return r;
	}

	@GET
	@Path("/nomedoRemedio/{nome}")
	public List<Remedio> getByNome(@PathParam("nome") String nomeRemedio) {
		List<Remedio> remedios = remedioService.getByNome(nomeRemedio);
		return remedios;
	}
	
	@DELETE
	@Path("{nomeRemedio}")
	public String delete(@PathParam("nomeRemedio") String nomeRemedio) {
		remedioService.delete(nomeRemedio);
		return nomeRemedio;
	}

	@POST
	public Remedio post(Remedio d) {
		remedioService.save(d);
		return d ;
	}

	@PUT
	public Remedio put(Remedio d) {
		remedioService.save(d);
		return d;
	}
}
