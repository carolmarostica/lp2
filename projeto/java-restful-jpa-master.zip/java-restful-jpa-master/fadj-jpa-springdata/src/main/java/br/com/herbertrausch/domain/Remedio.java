package br.com.herbertrausch.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Remedio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String fotoRemedio;
	private String nomeRemedio;
	private int dose;
	private int hrHr;
	private int qntsDias;
	private String comer;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nomeRemedio;
	}
	public void setNome(String nomeRemedio) {
		this.nomeRemedio = nomeRemedio;
	}
	public int getDose() {
		return dose;
	}
	public void setDose(int dose) {
		this.dose = dose;
	}
	public int getHrHr() {
		return hrHr;
	}
	public void setHrHr(int hrHr) {
		this.hrHr = hrHr;
	}
	public int getQntsDias() {
		return qntsDias;
	}
	public void setQntsDias(int qntsDias) {
		this.qntsDias = qntsDias;
	}
	public String getComer() {
		return comer;
	}
	public void setComer(String comer) {
		this.comer = comer;
	}
	public String getFoto() {
		return fotoRemedio;
	}
	public void setFotoRemedio(String fotoRemedio) {
		this.fotoRemedio = fotoRemedio;
	}
	
	@Override
	public String toString() {
		return "Remedio [id=" + id + ", Nome=" + nomeRemedio + ",Foto=" + fotoRemedio +", Dose=" + dose + ", De quantas em quantas horas=" + hrHr + ", Por quantos dias=" + qntsDias + ", Comer=" + comer + "]";
	}
	
}
