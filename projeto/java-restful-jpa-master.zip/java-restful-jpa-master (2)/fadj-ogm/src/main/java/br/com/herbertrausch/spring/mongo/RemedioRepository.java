package br.com.herbertrausch.spring.mongo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RemedioRepository extends MongoRepository<Remedio, String> {

	List<Remedio> findByNomeRemedio(String nomeRemedio);
	void deleteBynomeRemedio(String nomeRemedio);
	List<Remedio> findByFotoRemedio(String fotoRemedio);
	List<Remedio> findByComer(String comer);
	List<Remedio> findByQntsDias(int qntsDias);
	List<Remedio> findByHrHr(int hrHr);
	List<Remedio> findByDose(int dose);
	
}
