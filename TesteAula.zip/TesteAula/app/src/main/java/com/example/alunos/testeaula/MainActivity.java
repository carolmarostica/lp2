package com.example.alunos.testeaula;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void enviarTela2(View v){


        EditText inputNome = (EditText) findViewById(R.id.editText);
        String nome = inputNome.getText().toString();

        Intent it = new Intent(this, Tela2Activity.class);

        Bundle parametros = new Bundle();
        parametros.putString("nome_digitado", nome);
        it.putExtras(parametros);
        startActivity(it);
    }


}
