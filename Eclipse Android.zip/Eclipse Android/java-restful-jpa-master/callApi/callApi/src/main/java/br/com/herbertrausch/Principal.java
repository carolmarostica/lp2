package br.com.herbertrausch;

import java.util.ArrayList;

import br.com.herbertrausch.domain.Endereco;
import br.com.herbertrausch.rest.RestFulClient;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RestFulClient ws = new RestFulClient();
		
		
		
		//LISTAR TODOS
		ws.recuperar("http://localhost:8080/restmongo/rest/remedio");
		
		//LISTAR POR NOME
		String remedio = "dipirona"; //findviewbyid ... getText()
		ws.recuperar("http://localhost:8080/restmongo/rest/nomedoRemedio/"+remedio);
		
		//SALVAR
		ws.salvar("http://localhost:8080/restmongo/rest/remedio", "{id:3, fotoRemedio:foto.jpg,nomeRemedio:Dorflex,dose:2mg,hrHr:4, qntsDias:30, comer:sim}");
		
		//ATUALIZAR
		ws.salvar("http://localhost:8080/restmongo/rest/remedio", "{id:3, fotoRemedio:foto1.jpg,nomeRemedio:Dorflex,dose:2mg,hrHr:4, qntsDias:30, comer:sim}");
		
		//ATUALIZAR
		ws.deletar("http://localhost:8080/restmongo/rest/remedio/deletar/"+remedio);
						
		ws.closeConnection();
		

	}

}
